################################################################################
# REDUCCIÓN DE RANGO EN COVARIANZAS ESPACIALES
# Modelamiento espacial de disparidades en precios de derivados agropecuarios
# 
# Universidad Nacional del Altiplano
# Estudiante: Luz Bella Valenzuela Narvaez
# Curso: Estadística Espacial
# Docente: Ing. Fred Torres Cruz
# Fecha: Octubre 2025
################################################################################

# ==============================================================================
# 1. INSTALACIÓN Y CARGA DE PAQUETES
# ==============================================================================




# Cargar librerías

library(tidyverse)
library(sf)
library(sp)
library(geoR)
library(fields)
library(spdep)
library(viridis)
library(ggplot2)
library(gridExtra)
library(spNNGP)



# Configuración general
options(scipen = 999, digits = 4)
set.seed(123)

# ==============================================================================
# 2. CARGA Y EXPLORACIÓN INICIAL DE DATOS
# ==============================================================================


# Cargar datos
datos_raw <- read.csv("11_Cap400c.csv", stringsAsFactors = FALSE, 
                      na.strings = c("NA", "", " ", "NULL"))

cat("✓ Datos cargados\n")
cat("  Dimensiones:", nrow(datos_raw), "filas x", ncol(datos_raw), "columnas\n\n")

# Mostrar estructura
cat("Estructura de las primeras columnas:\n")
str(datos_raw[, 1:15])

cat("\nNombres de todas las columnas:\n")
print(names(datos_raw))



# ==============================================================================
# 3. LIMPIEZA Y PREPARACIÓN DE DATOS
# ==============================================================================

cat("\n=== LIMPIEZA Y PREPARACIÓN DE DATOS ===\n")

# Primero, veamos qué columnas existen realmente
cat("Columnas disponibles en el dataset:\n")
print(names(datos_raw))
cat("\n")

# Identificar columnas de forma flexible
col_anio <- names(datos_raw)[grepl("ANIO|ANO|^A$", names(datos_raw), ignore.case = TRUE)][1]
col_ccdd <- names(datos_raw)[grepl("^CCDD$|COD.*DEP", names(datos_raw), ignore.case = TRUE)][1]
col_ccpp <- names(datos_raw)[grepl("^CCPP$|COD.*PROV", names(datos_raw), ignore.case = TRUE)][1]
col_ccdi <- names(datos_raw)[grepl("^CCDI$|COD.*DIST", names(datos_raw), ignore.case = TRUE)][1]
col_nombdedo <- names(datos_raw)[grepl("NOMBDEDO|NOMBREDO|DEPARTAMENTO|DEPART", names(datos_raw), ignore.case = TRUE)][1]
col_region <- names(datos_raw)[grepl("^REGION$|REGI.N", names(datos_raw), ignore.case = TRUE)][1]
col_dominio <- names(datos_raw)[grepl("^DOMINIO$", names(datos_raw), ignore.case = TRUE)][1]
col_factor <- names(datos_raw)[grepl("^FACTOR$", names(datos_raw), ignore.case = TRUE)][1]
col_codqso <- names(datos_raw)[grepl("CODQSO|CODQUESO|COD.*QSO", names(datos_raw), ignore.case = TRUE)][1]

# Para las variables P (precios/producción)
col_p102_1 <- names(datos_raw)[grepl("^P102.1|P102_1", names(datos_raw), ignore.case = TRUE)][1]
col_p102_2 <- names(datos_raw)[grepl("^P102.2|P102_2", names(datos_raw), ignore.case = TRUE)][1]

cat("Columnas identificadas:\n")
cat("  ANIO:", ifelse(is.na(col_anio), "NO ENCONTRADA", col_anio), "\n")
cat("  CCDD:", ifelse(is.na(col_ccdd), "NO ENCONTRADA", col_ccdd), "\n")
cat("  CCPP:", ifelse(is.na(col_ccpp), "NO ENCONTRADA", col_ccpp), "\n")
cat("  CCDI:", ifelse(is.na(col_ccdi), "NO ENCONTRADA", col_ccdi), "\n")
cat("  Departamento:", ifelse(is.na(col_nombdedo), "NO ENCONTRADA", col_nombdedo), "\n")
cat("  Region:", ifelse(is.na(col_region), "NO ENCONTRADA", col_region), "\n")
cat("  P102_1:", ifelse(is.na(col_p102_1), "NO ENCONTRADA", col_p102_1), "\n")
cat("  P102_2:", ifelse(is.na(col_p102_2), "NO ENCONTRADA", col_p102_2), "\n\n")

# Seleccionar solo las columnas que existen
cols_disponibles <- c(col_anio, col_ccdd, col_ccpp, col_ccdi, col_nombdedo, 
                      col_region, col_dominio, col_factor, col_codqso,
                      col_p102_1, col_p102_2)
cols_disponibles <- cols_disponibles[!is.na(cols_disponibles)]

# También incluir todas las columnas que empiezan con P4
cols_p4 <- names(datos_raw)[grepl("^P4", names(datos_raw), ignore.case = TRUE)]
cols_disponibles <- unique(c(cols_disponibles, cols_p4))

cat("Seleccionando", length(cols_disponibles), "columnas relevantes\n")

# Seleccionar y limpiar datos
datos_limpios <- datos_raw %>%
  select(all_of(cols_disponibles))

# Renombrar columnas de forma estándar si existen
if(!is.na(col_anio)) datos_limpios <- rename(datos_limpios, ANIO = !!col_anio)
if(!is.na(col_ccdd)) datos_limpios <- rename(datos_limpios, CCDD = !!col_ccdd)
if(!is.na(col_ccpp)) datos_limpios <- rename(datos_limpios, CCPP = !!col_ccpp)
if(!is.na(col_ccdi)) datos_limpios <- rename(datos_limpios, CCDI = !!col_ccdi)
if(!is.na(col_nombdedo)) datos_limpios <- rename(datos_limpios, NOMBDEDO = !!col_nombdedo)
if(!is.na(col_region)) datos_limpios <- rename(datos_limpios, REGION = !!col_region)
if(!is.na(col_p102_1)) datos_limpios <- rename(datos_limpios, P102_1 = !!col_p102_1)
if(!is.na(col_p102_2)) datos_limpios <- rename(datos_limpios, P102_2 = !!col_p102_2)

# Convertir a numérico y crear variable precio
datos_limpios <- datos_limpios %>%
  mutate(
    precio = as.numeric(ifelse("P102_1" %in% names(.), P102_1, NA)),
    cantidad = as.numeric(ifelse("P102_2" %in% names(.), P102_2, NA)),
    CCDD = as.character(ifelse("CCDD" %in% names(.), CCDD, NA)),
    CCPP = as.character(ifelse("CCPP" %in% names(.), CCPP, NA)),
    CCDI = as.character(ifelse("CCDI" %in% names(.), CCDI, NA))
  ) %>%
  # Filtrar observaciones válidas
  filter(
    !is.na(precio),
    precio > 0,
    precio < 9999  # Eliminar valores extremos
  )

cat("\n✓ Datos después de limpieza:", nrow(datos_limpios), "observaciones\n")
cat("  Observaciones eliminadas:", nrow(datos_raw) - nrow(datos_limpios), "\n")

# Si no hay datos válidos, intentar con otras columnas de precio
if(nrow(datos_limpios) == 0) {
  cat("\n⚠ ADVERTENCIA: No se encontraron datos válidos con P102_1\n")
  cat("  Buscando columnas alternativas de precio...\n")
  
  # Buscar cualquier columna que pueda ser precio
  cols_precio <- names(datos_raw)[grepl("PREC|PRE_|PRECIO|P[0-9]+.*1", names(datos_raw), ignore.case = TRUE)]
  
  if(length(cols_precio) > 0) {
    cat("  Columnas de precio encontradas:", paste(cols_precio, collapse = ", "), "\n")
    cat("  Usando:", cols_precio[1], "\n")
    
    datos_limpios <- datos_raw %>%
      mutate(
        precio = as.numeric(!!sym(cols_precio[1])),
        CCDD = as.character(ifelse(!is.na(col_ccdd), !!sym(col_ccdd), NA)),
        CCPP = as.character(ifelse(!is.na(col_ccpp), !!sym(col_ccpp), NA)),
        CCDI = as.character(ifelse(!is.na(col_ccdi), !!sym(col_ccdi), NA))
      ) %>%
      filter(!is.na(precio), precio > 0, precio < 9999)
    
    cat("✓ Datos válidos encontrados:", nrow(datos_limpios), "\n")
  }
}

# ==============================================================================
# 4. GEOCODIFICACIÓN (CREAR COORDENADAS)
# ==============================================================================

cat("\n=== GEOCODIFICACIÓN DE UBICACIONES ===\n")

# Verificar qué columnas de ubicación existen
cols_existentes <- names(datos_limpios)
tiene_nombdedo <- "NOMBDEDO" %in% cols_existentes
tiene_region <- "REGION" %in% cols_existentes
tiene_ccdd <- "CCDD" %in% cols_existentes
tiene_ccpp <- "CCPP" %in% cols_existentes
tiene_ccdi <- "CCDI" %in% cols_existentes

cat("Columnas de ubicación disponibles:\n")
cat("  NOMBDEDO:", tiene_nombdedo, "\n")
cat("  REGION:", tiene_region, "\n")
cat("  CCDD:", tiene_ccdd, "\n")
cat("  CCPP:", tiene_ccpp, "\n")
cat("  CCDI:", tiene_ccdi, "\n\n")

# Crear UBIGEO si tenemos los códigos
if(tiene_ccdd & tiene_ccpp & tiene_ccdi) {
  datos_limpios <- datos_limpios %>%
    mutate(
      UBIGEO = paste0(
        str_pad(as.character(CCDD), 2, "left", "0"),
        str_pad(as.character(CCPP), 2, "left", "0"),
        str_pad(as.character(CCDI), 2, "left", "0")
      )
    )
  cat("✓ UBIGEO creado a partir de códigos\n")
} else {
  # Si no tenemos códigos completos, crear ID de ubicación alternativo
  cat("⚠ No se encontraron todos los códigos UBIGEO\n")
  cat("  Creando identificador de ubicación alternativo...\n")
  
  # Usar la primera columna de ubicación que tengamos
  if(tiene_ccdd) {
    datos_limpios <- datos_limpios %>%
      mutate(UBIGEO = paste0("LOC_", str_pad(as.character(CCDD), 4, "left", "0")))
  } else {
    datos_limpios <- datos_limpios %>%
      mutate(UBIGEO = paste0("LOC_", row_number()))
  }
}

# Calcular centroide por UBIGEO (coordenadas sintéticas)
# IMPORTANTE: Reemplazar con coordenadas reales si las tienes
set.seed(123)

# Preparar agrupación solo con columnas que existen
if(tiene_nombdedo & tiene_region) {
  coordenadas_ubigeo <- datos_limpios %>%
    group_by(UBIGEO, NOMBDEDO, REGION) %>%
    summarise(n = n(), .groups = "drop")
} else if(tiene_region) {
  coordenadas_ubigeo <- datos_limpios %>%
    group_by(UBIGEO, REGION) %>%
    summarise(n = n(), .groups = "drop")
} else if(tiene_nombdedo) {
  coordenadas_ubigeo <- datos_limpios %>%
    group_by(UBIGEO, NOMBDEDO) %>%
    summarise(n = n(), .groups = "drop")
} else {
  coordenadas_ubigeo <- datos_limpios %>%
    group_by(UBIGEO) %>%
    summarise(n = n(), .groups = "drop")
}

# Agregar coordenadas sintéticas
coordenadas_ubigeo <- coordenadas_ubigeo %>%
  mutate(
    # Coordenadas aproximadas de Perú: -18 a -0 lat, -81 a -68 lon
    latitud = runif(n(), -18, -0),
    longitud = runif(n(), -81, -68)
  )

cat("✓ Coordenadas sintéticas generadas para", nrow(coordenadas_ubigeo), "ubicaciones\n")
cat("  ⚠ NOTA: Estas son coordenadas ALEATORIAS. Para análisis real,\n")
cat("    reemplazar con coordenadas geográficas reales.\n\n")

# Unir coordenadas al dataset
datos_limpios <- datos_limpios %>%
  left_join(coordenadas_ubigeo %>% select(UBIGEO, latitud, longitud), 
            by = "UBIGEO")

cat("✓ Geocodificación completada\n")
cat("  Ubicaciones únicas:", n_distinct(datos_limpios$UBIGEO), "\n")

# Verificar si las columnas de coordenadas existen después del join
if("latitud" %in% names(datos_limpios) & "longitud" %in% names(datos_limpios)) {
  # Verificar datos con coordenadas válidas
  n_antes <- nrow(datos_limpios)
  datos_limpios <- datos_limpios %>%
    filter(!is.na(latitud), !is.na(longitud))
  n_despues <- nrow(datos_limpios)
  
  cat("  Observaciones con coordenadas válidas:", n_despues, "\n")
  if(n_antes != n_despues) {
    cat("  Observaciones sin coordenadas eliminadas:", n_antes - n_despues, "\n")
  }
} else {
  cat("  ⚠ ERROR: No se pudieron unir las coordenadas\n")
  cat("  Columnas disponibles:", paste(names(datos_limpios), collapse = ", "), "\n")
  stop("No se pueden continuar sin coordenadas")
}


# Guardar las coordenadas por si el usuario quiere reemplazarlas
write.csv(coordenadas_ubigeo, "coordenadas_generadas.csv", row.names = FALSE)
cat("✓ Coordenadas guardadas en 'coordenadas_generadas.csv'\n")
cat("  Puedes editar este archivo con coordenadas reales y volver a ejecutar.\n\n")

cat("IMPORTANTE: Las coordenadas son SINTÉTICAS (aleatorias).\n")
cat("Para análisis real, reemplaza con coordenadas geográficas verdaderas.\n")
cat("Puedes cargar coordenadas reales así:\n")
cat('  coords_reales <- read.csv("coordenadas_reales.csv")\n')
cat('  datos_limpios <- datos_limpios %>% select(-latitud, -longitud) %>%\n')
cat('                   left_join(coords_reales, by = "UBIGEO")\n')

# ==============================================================================
# 5. ANÁLISIS EXPLORATORIO DE DATOS (EDA)
# ==============================================================================

cat("\n=== ANÁLISIS EXPLORATORIO DE DATOS ===\n")

# Verificar columnas disponibles para el análisis
tiene_nombdedo <- "NOMBDEDO" %in% names(datos_limpios)
tiene_region <- "REGION" %in% names(datos_limpios)

# 5.1 Estadísticas descriptivas globales
if(tiene_nombdedo) {
  estadisticas <- datos_limpios %>%
    summarise(
      n = n(),
      n_ubicaciones = n_distinct(UBIGEO),
      n_departamentos = n_distinct(NOMBDEDO),
      media = mean(precio, na.rm = TRUE),
      mediana = median(precio, na.rm = TRUE),
      desv_est = sd(precio, na.rm = TRUE),
      minimo = min(precio, na.rm = TRUE),
      maximo = max(precio, na.rm = TRUE),
      q25 = quantile(precio, 0.25, na.rm = TRUE),
      q75 = quantile(precio, 0.75, na.rm = TRUE),
      cv = (sd(precio, na.rm = TRUE) / mean(precio, na.rm = TRUE)) * 100,
      dispersion = ((max(precio, na.rm = TRUE) - min(precio, na.rm = TRUE)) / 
                      mean(precio, na.rm = TRUE)) * 100
    )
} else {
  estadisticas <- datos_limpios %>%
    summarise(
      n = n(),
      n_ubicaciones = n_distinct(UBIGEO),
      media = mean(precio, na.rm = TRUE),
      mediana = median(precio, na.rm = TRUE),
      desv_est = sd(precio, na.rm = TRUE),
      minimo = min(precio, na.rm = TRUE),
      maximo = max(precio, na.rm = TRUE),
      q25 = quantile(precio, 0.25, na.rm = TRUE),
      q75 = quantile(precio, 0.75, na.rm = TRUE),
      cv = (sd(precio, na.rm = TRUE) / mean(precio, na.rm = TRUE)) * 100,
      dispersion = ((max(precio, na.rm = TRUE) - min(precio, na.rm = TRUE)) / 
                      mean(precio, na.rm = TRUE)) * 100
    )
}

cat("\n--- ESTADÍSTICAS DESCRIPTIVAS GLOBALES ---\n")
print(as.data.frame(t(estadisticas)))

# 5.2 Análisis por región (si existe)
if(tiene_region) {
  stats_region <- datos_limpios %>%
    group_by(REGION) %>%
    summarise(
      n = n(),
      n_ubigeos = n_distinct(UBIGEO),
      media = mean(precio, na.rm = TRUE),
      desv_est = sd(precio, na.rm = TRUE),
      minimo = min(precio, na.rm = TRUE),
      maximo = max(precio, na.rm = TRUE),
      cv = (sd(precio, na.rm = TRUE) / mean(precio, na.rm = TRUE)) * 100,
      .groups = "drop"
    ) %>%
    arrange(desc(media))
  
  cat("\n--- ESTADÍSTICAS POR REGIÓN ---\n")
  print(stats_region)
} else {
  cat("\n⚠ No hay variable REGION disponible\n")
  stats_region <- NULL
}

# 5.3 Análisis por departamento (si existe)
if(tiene_nombdedo) {
  stats_depto <- datos_limpios %>%
    group_by(NOMBDEDO) %>%
    summarise(
      n = n(),
      media = mean(precio, na.rm = TRUE),
      desv_est = sd(precio, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    arrange(desc(media)) %>%
    head(15)
  
  cat("\n--- TOP 15 DEPARTAMENTOS POR PRECIO PROMEDIO ---\n")
  print(stats_depto)
} else {
  # Análisis alternativo por UBIGEO
  cat("\n--- TOP 15 UBICACIONES POR PRECIO PROMEDIO ---\n")
  stats_depto <- datos_limpios %>%
    group_by(UBIGEO) %>%
    summarise(
      n = n(),
      media = mean(precio, na.rm = TRUE),
      desv_est = sd(precio, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    arrange(desc(media)) %>%
    head(15)
  
  print(stats_depto)
}









# ==============================================================================
# 6. VISUALIZACIONES EXPLORATORIAS
# ==============================================================================

cat("\n=== GENERANDO GRÁFICOS EXPLORATORIOS ===\n")

# 6.1 Histograma de precios
p1 <- ggplot(datos_limpios, aes(x = precio)) +
  geom_histogram(bins = 40, fill = "#2E86AB", color = "white", alpha = 0.85) +
  geom_vline(aes(xintercept = mean(precio)), 
             color = "#A23B72", linetype = "dashed", linewidth = 1.2) +
  geom_vline(aes(xintercept = median(precio)), 
             color = "#F18F01", linetype = "dashed", linewidth = 1.2) +
  labs(
    title = "Distribución de Precios de Derivados Agropecuarios",
    subtitle = sprintf("Media: S/ %.2f | Mediana: S/ %.2f | CV: %.1f%%", 
                       estadisticas$media, estadisticas$mediana, estadisticas$cv),
    x = "Precio (S/ por unidad)",
    y = "Frecuencia",
    caption = "Fuente: ENA 2021"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(color = "gray40"),
    panel.grid.minor = element_blank()
  )

ggsave("01_histograma_precios.png", p1, width = 12, height = 7, dpi = 300)
cat("✓ Histograma guardado\n")

# 11.2 Mapa de incertidumbre
p_incert <- ggplot() +
  geom_raster(data = grid_pred, 
              aes(x = longitud, y = latitud, fill = pred_sd)) +
  geom_point(data = datos_espaciales, 
             aes(x = longitud, y = latitud), 
             size = 1, alpha = 0.4, color = "black") +
  scale_fill_viridis(option = "magma", 
                     name = "Desv.\nEstándar\nPredictiva") +
  labs(
    title = "Mapa de Incertidumbre Predictiva",
    subtitle = "Mayor incertidumbre en zonas alejadas de observaciones",
    x = "Longitud",
    y = "Latitud"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(color = "gray40"),
    legend.position = "right"
  )

ggsave("08_mapa_incertidumbre.png", p_incert, width = 14, height = 10, dpi = 300)

# 11.3 Mapa de intervalos de confianza (ancho)
grid_pred$ic_width <- grid_pred$pred_q975 - grid_pred$pred_q025

p_ic <- ggplot() +
  geom_raster(data = grid_pred, 
              aes(x = longitud, y = latitud, fill = ic_width)) +
  scale_fill_gradient2(low = "#2E86AB", mid = "#F4E409", high = "#A23B72",
                       midpoint = median(grid_pred$ic_width),
                       name = "Amplitud\nIC 95%") +
  labs(
    title = "Amplitud del Intervalo de Confianza al 95%",
    x = "Longitud",
    y = "Latitud"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    legend.position = "right"
  )

ggsave("09_mapa_ic_amplitud.png", p_ic, width = 14, height = 10, dpi = 300)

cat("✓ Mapas predictivos guardados\n")

# ==============================================================================
# 12. CLASIFICACIÓN DE ZONAS
# ==============================================================================

cat("\n=== CLASIFICACIÓN DE ZONAS DE INTERÉS ===\n")

if(!exists("grid_pred")) {
  cat("⚠ Saltando clasificación de zonas (grid_pred no existe)\n\n")
} else {
  # Clasificar según desviación estándar del precio medio
  precio_medio_pred <- mean(grid_pred$pred_precio)
  precio_sd_pred <- sd(grid_pred$pred_precio)
  
  grid_pred <- grid_pred %>%
    mutate(
      zona_tipo = case_when(
        pred_precio < (precio_medio_pred - 0.5 * precio_sd_pred) ~ "Bajo Precio",
        pred_precio > (precio_medio_pred + 0.5 * precio_sd_pred) ~ "Alto Precio",
        TRUE ~ "Precio Medio"
      ),
      zona_tipo = factor(zona_tipo, 
                         levels = c("Bajo Precio", "Precio Medio", "Alto Precio"))
    )
  
  # Resumen por tipo de zona
  tabla_zonas <- grid_pred %>%
    group_by(zona_tipo) %>%
    summarise(
      n_celdas = n(),
      precio_promedio = mean(pred_precio),
      precio_min = min(pred_precio),
      precio_max = max(pred_precio),
      incertidumbre_promedio = mean(pred_sd),
      .groups = "drop"
    )
  
  cat("\n--- RESUMEN DE ZONAS ---\n")
  print(tabla_zonas)
  
  # Mapa de clasificación
  if(exists("datos_espaciales")) {
    p_zonas <- ggplot() +
      geom_raster(data = grid_pred, 
                  aes(x = longitud, y = latitud, fill = zona_tipo)) +
      geom_point(data = datos_espaciales, 
                 aes(x = longitud, y = latitud), 
                 size = 1.5, alpha = 0.5, color = "black") +
      scale_fill_manual(
        values = c("Bajo Precio" = "#d73027", 
                   "Precio Medio" = "#fee08b", 
                   "Alto Precio" = "#1a9850"),
        name = "Clasificación"
      ) +
      labs(
        title = "Clasificación de Zonas según Nivel de Precios",
        subtitle = "Identificación de barreras de mercado y zonas prioritarias",
        x = "Longitud",
        y = "Latitud",
        caption = "Puntos negros: ubicaciones observadas"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        plot.title = element_text(face = "bold", size = 14),
        plot.subtitle = element_text(color = "gray40"),
        legend.position = "right"
      )
    
    ggsave("10_mapa_clasificacion_zonas.png", p_zonas, width = 14, height = 10, dpi = 300)
    cat("\n✓ Mapa de clasificación guardado\n")
  }
}

# ==============================================================================
# 13. VALIDACIÓN CRUZADA
# ==============================================================================

cat("\n=== VALIDACIÓN CRUZADA ===\n")

# K-fold cross-validation (5 folds)
set.seed(123)
n_folds <- 5
fold_size <- floor(n_obs / n_folds)
indices <- sample(1:n_obs)

predicciones_cv <- numeric(n_obs)
observados_cv <- datos_espaciales$precio_medio

cat("Realizando validación cruzada con", n_folds, "folds...\n")

for(fold in 1:n_folds) {
  cat("  Fold", fold, "de", n_folds, "\n")
  
  # Índices de test
  test_start <- (fold - 1) * fold_size + 1
  test_end <- ifelse(fold == n_folds, n_obs, fold * fold_size)
  test_idx <- indices[test_start:test_end]
  train_idx <- setdiff(1:n_obs, test_idx)
  
  # Predicción usando vecinos más cercanos (método simple)
  for(i in test_idx) {
    coords_test <- matrix(coords[i, ], nrow = 1)
    coords_train <- coords[train_idx, ]
    
    # Calcular distancias
    dists <- sqrt(rowSums((coords_train - 
                             coords_test[rep(1, nrow(coords_train)), ])^2))
    
    # Promedio ponderado por inverso de distancia
    k_neighbors <- min(10, length(train_idx))
    vecinos_idx <- order(dists)[1:k_neighbors]
    pesos <- 1 / (dists[vecinos_idx] + 0.001)  # Evitar división por cero
    pesos <- pesos / sum(pesos)
    
    predicciones_cv[i] <- sum(observados_cv[train_idx][vecinos_idx] * pesos)
  }
}

# Calcular métricas
rmse_cv <- sqrt(mean((observados_cv - predicciones_cv)^2))
mae_cv <- mean(abs(observados_cv - predicciones_cv))
mape_cv <- mean(abs((observados_cv - predicciones_cv) / observados_cv)) * 100
r2_cv <- cor(observados_cv, predicciones_cv)^2

cat("\n--- MÉTRICAS DE VALIDACIÓN CRUZADA ---\n")
cat("RMSE:", round(rmse_cv, 4), "\n")
cat("MAE:", round(mae_cv, 4), "\n")
cat("MAPE:", round(mape_cv, 2), "%\n")
cat("R²:", round(r2_cv, 4), "\n")

# Gráfico observados vs predichos
df_cv <- data.frame(
  observado = observados_cv,
  predicho = predicciones_cv,
  residuo = observados_cv - predicciones_cv
)

p_cv1 <- ggplot(df_cv, aes(x = observado, y = predicho)) +
  geom_point(alpha = 0.6, color = "#2E86AB", size = 2.5) +
  geom_abline(intercept = 0, slope = 1, color = "#A23B72", 
              linetype = "dashed", size = 1.2) +
  geom_smooth(method = "lm", se = TRUE, color = "#F18F01", size = 1) +
  labs(
    title = "Validación Cruzada: Observados vs Predichos",
    subtitle = sprintf("R² = %.3f | RMSE = %.3f | MAE = %.3f", 
                       r2_cv, rmse_cv, mae_cv),
    x = "Precios Observados (S/)",
    y = "Precios Predichos (S/)"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    plot.subtitle = element_text(color = "gray40")
  )

# Gráfico de residuos
p_cv2 <- ggplot(df_cv, aes(x = predicho, y = residuo)) +
  geom_point(alpha = 0.6, color = "#2E86AB", size = 2.5) +
  geom_hline(yintercept = 0, color = "#A23B72", linetype = "dashed", size = 1.2) +
  geom_smooth(method = "loess", se = TRUE, color = "#F18F01") +
  labs(
    title = "Diagnóstico de Residuos",
    x = "Precios Predichos (S/)",
    y = "Residuos"
  ) +
  theme_minimal(base_size = 12) +
  theme(plot.title = element_text(face = "bold"))

# Combinar gráficos
p_cv_combined <- grid.arrange(p_cv1, p_cv2, ncol = 2)

ggsave("11_validacion_cruzada.png", p_cv_combined, width = 16, height = 7, dpi = 300)

cat("✓ Gráficos de validación guardados\n")

# ==============================================================================
# 14. INTEGRACIÓN ESPACIAL DE MERCADOS
# ==============================================================================

cat("\n=== ANÁLISIS DE INTEGRACIÓN DE MERCADOS ===\n")

# Calcular rango efectivo
phi_mediana <- median(samples[, "phi"])
nu <- 1.5  # Para modelo exponencial, aproximadamente

# Para modelo exponencial: rango efectivo ≈ 3/φ (donde correlación ≈ 0.05)
rango_efectivo <- 3 / phi_mediana

cat("\n--- INTEGRACIÓN ESPACIAL DE MERCADOS ---\n")
cat("Phi estimado:", round(phi_mediana, 4), "\n")
cat("Rango efectivo:", round(rango_efectivo, 4), "grados\n")
cat("Aprox. en km (1° ≈ 111 km):", round(rango_efectivo * 111, 2), "km\n")

# Distancia media entre observaciones
dist_promedio <- mean(dist_matrix[upper.tri(dist_matrix)])
cat("\nDistancia promedio entre ubicaciones:", round(dist_promedio, 4), "grados\n")
cat("Aprox. en km:", round(dist_promedio * 111, 2), "km\n")

# Índice de integración
indice_integracion <- rango_efectivo / dist_promedio

cat("\n--- ÍNDICE DE INTEGRACIÓN ESPACIAL ---\n")
cat("Índice:", round(indice_integracion, 2), "\n")

if(indice_integracion > 2) {
  cat("Interpretación: ALTA INTEGRACIÓN\n")
  cat("  Los mercados están bien conectados espacialmente\n")
} else if(indice_integracion > 1) {
  cat("Interpretación: INTEGRACIÓN MODERADA\n")
  cat("  Hay cierta conexión espacial entre mercados\n")
} else {
  cat("Interpretación: BAJA INTEGRACIÓN / MERCADOS FRAGMENTADOS\n")
  cat("  Los mercados están espacialmente desconectados\n")
}

# Proporción de varianza explicada por estructura espacial
sigma2_med <- median(samples[, "sigma.sq"])
tau2_med <- median(samples[, "tau.sq"])
prop_espacial <- sigma2_med / (sigma2_med + tau2_med)

cat("\n--- ESTRUCTURA DE VARIANZA ---\n")
cat("Varianza espacial (σ²):", round(sigma2_med, 4), "\n")
cat("Varianza nugget (τ²):", round(tau2_med, 4), "\n")
cat("Proporción espacial:", round(prop_espacial * 100, 2), "%\n")
cat("Proporción no espacial:", round((1-prop_espacial) * 100, 2), "%\n")

# ==============================================================================
# 15. IDENTIFICACIÓN DE ZONAS PRIORITARIAS
# ==============================================================================

cat("\n=== IDENTIFICACIÓN DE ZONAS PRIORITARIAS ===\n")

# Identificar zonas de bajo precio con datos observados
zonas_bajo_precio <- datos_espaciales %>%
  filter(precio_medio < (mean(precio_medio) - 0.5 * sd(precio_medio))) %>%
  arrange(precio_medio)

cat("\n--- TOP 10 ZONAS DE BAJO PRECIO (Prioritarias) ---\n")
zonas_prioritarias <- zonas_bajo_precio %>%
  head(10) %>%
  select(UBIGEO, NOMBDEDO, REGION, precio_medio, n_obs)

print(zonas_prioritarias)

# Zonas de alto precio (posible poder de mercado)
zonas_alto_precio <- datos_espaciales %>%
  filter(precio_medio > (mean(precio_medio) + 0.5 * sd(precio_medio))) %>%
  arrange(desc(precio_medio))

cat("\n--- TOP 10 ZONAS DE ALTO PRECIO ---\n")
zonas_alto <- zonas_alto_precio %>%
  head(10) %>%
  select(UBIGEO, NOMBDEDO, REGION, precio_medio, n_obs)

print(zonas_alto)

# Exportar a CSV
write.csv(zonas_prioritarias, "zonas_prioritarias_bajo_precio.csv", row.names = FALSE)
write.csv(zonas_alto, "zonas_alto_precio.csv", row.names = FALSE)

cat("\n✓ Zonas prioritarias exportadas a CSV\n")

# ==============================================================================
# 16. COMPARACIÓN DE COMPLEJIDAD COMPUTACIONAL
# ==============================================================================

cat("\n=== COMPARACIÓN DE EFICIENCIA COMPUTACIONAL ===\n")

n_obs_ejemplo <- c(1000, 2000, 5000, 10000)

# Complejidad teórica
gp_completo <- n_obs_ejemplo^3
rango_reducido_r30 <- n_obs_ejemplo * 30^2
nngp_m15 <- n_obs_ejemplo * 15^2

tabla_complejidad <- data.frame(
  N = n_obs_ejemplo,
  GP_Completo = format(gp_completo, scientific = TRUE, digits = 2),
  Rango_Reducido = format(rango_reducido_r30, scientific = TRUE, digits = 2),
  NNGP = format(nngp_m15, scientific = TRUE, digits = 2),
  Reduccion_vs_GP = paste0(round(gp_completo / nngp_m15, 0), "x")
)

cat("\n--- OPERACIONES NECESARIAS (Orden de magnitud) ---\n")
print(tabla_complejidad)

cat("\n--- TIEMPO DE EJECUCIÓN (Modelo actual) ---\n")
cat("N observaciones:", n_obs, "\n")
cat("Tiempo spNNGP:", round(tiempo_total, 2), "minutos\n")
cat("Tiempo estimado GP completo:", 
    round(tiempo_total * (n_obs^3) / (n_obs * 15^2) / 60, 1), "horas\n")

# ==============================================================================
# 17. REPORTE FINAL
# ==============================================================================

cat("\n=== GENERANDO REPORTE FINAL ===\n")

# Guardar workspace
save(
  datos_limpios,
  datos_espaciales,
  estadisticas,
  stats_region,
  moran_resultado,
  vario_matern,
  modelo_nngp,
  samples,
  grid_pred,
  tabla_zonas,
  df_cv,
  zonas_prioritarias,
  zonas_alto,
  file = "workspace_analisis_espacial.RData"
)

cat("✓ Workspace guardado en 'workspace_analisis_espacial.RData'\n")

# Crear reporte en texto
sink("REPORTE_COMPLETO.txt")
cat("================================================================================\n")
cat("       REPORTE DE ANÁLISIS ESPACIAL - PRECIOS AGROPECUARIOS EN PERÚ\n")
cat("================================================================================\n")
cat("\nUniversidad Nacional del Altiplano\n")
cat("Estudiante: Luz Bella Valenzuela Narvaez\n")
cat("Curso: Estadística Espacial\n")
cat("Docente: Ing. Fred Torres Cruz\n")
cat("Fecha:", format(Sys.Date(), "%d de %B de %Y"), "\n")
cat("\n================================================================================\n")
cat("1. RESUMEN EJECUTIVO\n")
cat("================================================================================\n\n")

cat("El análisis espacial de", n_obs, "ubicaciones en Perú revela:\n\n")

cat("• Heterogeneidad Espacial: Dispersión del", 
    round(estadisticas$dispersion, 1), "% en precios\n")
cat("• Coeficiente de Variación:", round(estadisticas$cv, 1), "%\n")
cat("• Autocorrelación Espacial (Moran's I):", 
    round(moran_resultado$estimate[1], 3), 
    ifelse(moran_resultado$p.value < 0.05, " (SIGNIFICATIVA)", " (no significativa)"), "\n")
cat("• Integración de Mercados:", 
    ifelse(indice_integracion > 2, "ALTA", 
           ifelse(indice_integracion > 1, "MODERADA", "BAJA")), "\n\n")

cat("================================================================================\n")
cat("2. DATOS Y METODOLOGÍA\n")
cat("================================================================================\n\n")

cat("2.1 Datos\n")
cat("   • Fuente: Encuesta Nacional Agropecuaria (ENA) 2021\n")
cat("   • Archivo: 11_Cap400c.csv\n")
cat("   • Observaciones totales:", nrow(datos_limpios), "\n")
cat("   • Ubicaciones únicas:", n_obs, "\n")
cat("   • Departamentos:", n_distinct(datos_espaciales$NOMBDEDO), "\n")
cat("   • Regiones naturales:", n_distinct(datos_espaciales$REGION), "\n\n")

cat("2.2 Metodología\n")
cat("   • Modelo: spNNGP (Nearest Neighbor Gaussian Process)\n")
cat("   • Número de vecinos (m): 15\n")
cat("   • Función de covarianza: Exponencial\n")
cat("   • Iteraciones MCMC: 3000\n")
cat("   • Burn-in: 500\n")
cat("   • Tiempo de ejecución:", round(tiempo_total, 2), "minutos\n\n")

cat("================================================================================\n")
cat("3. ESTADÍSTICAS DESCRIPTIVAS\n")
cat("================================================================================\n\n")

cat("Precio por kilogramo (S/):\n")
cat("   • Media:", sprintf("%.2f", estadisticas$media), "\n")
cat("   • Mediana:", sprintf("%.2f", estadisticas$mediana), "\n")
cat("   • Desviación estándar:", sprintf("%.2f", estadisticas$desv_est), "\n")
cat("   • Mínimo:", sprintf("%.2f", estadisticas$minimo), "\n")
cat("   • Máximo:", sprintf("%.2f", estadisticas$maximo), "\n")
cat("   • Q1:", sprintf("%.2f", estadisticas$q25), "\n")
cat("   • Q3:", sprintf("%.2f", estadisticas$q75), "\n")
cat("   • Coeficiente de variación:", sprintf("%.1f%%", estadisticas$cv), "\n\n")

cat("Por Región Natural:\n")
for(i in 1:nrow(stats_region)) {
  cat(sprintf("   • %s: Media = S/ %.2f (n = %d)\n",
              stats_region$REGION[i],
              stats_region$media[i],
              stats_region$n[i]))
}

cat("\n================================================================================\n")
cat("4. ANÁLISIS VARIOGRÁFICO\n")
cat("================================================================================\n\n")

cat("Parámetros del Modelo Matérn:\n")
cat("   • Nugget (τ²):", sprintf("%.4f", vario_matern$nugget), "\n")
cat("   • Sill parcial (σ²):", sprintf("%.4f", vario_matern$cov.pars[1]), "\n")
cat("   • Range (φ):", sprintf("%.4f", vario_matern$cov.pars[2]), "grados\n")
cat("   • Kappa (ν):", vario_matern$kappa, "\n")
cat("   • Sill total:", sprintf("%.4f", 
                                vario_matern$nugget + vario_matern$cov.pars[1]), "\n\n")

cat("================================================================================\n")
cat("5. RESULTADOS DEL MODELO spNNGP\n")
cat("================================================================================\n\n")

cat("Estimaciones Posteriores:\n\n")
print(resumen_params)

cat("\n\nVarianza:\n")
cat("   • Varianza espacial (σ²):", sprintf("%.4f", sigma2_med), 
    sprintf("(%.1f%%)", prop_espacial * 100), "\n")
cat("   • Varianza nugget (τ²):", sprintf("%.4f", tau2_med), 
    sprintf("(%.1f%%)", (1-prop_espacial) * 100), "\n\n")

cat("Integración Espacial:\n")
cat("   • Rango efectivo:", sprintf("%.2f", rango_efectivo), 
    "grados (≈", sprintf("%.0f", rango_efectivo * 111), "km)\n")
cat("   • Distancia promedio entre ubicaciones:", sprintf("%.2f", dist_promedio), 
    "grados (≈", sprintf("%.0f", dist_promedio * 111), "km)\n")
cat("   • Índice de integración:", sprintf("%.2f", indice_integracion), "\n")
cat("   • Interpretación:", 
    ifelse(indice_integracion > 2, "MERCADOS ALTAMENTE INTEGRADOS", 
           ifelse(indice_integracion > 1, "INTEGRACIÓN MODERADA", 
                  "MERCADOS FRAGMENTADOS")), "\n\n")

cat("================================================================================\n")
cat("6. VALIDACIÓN DEL MODELO\n")
cat("================================================================================\n\n")

cat("Validación Cruzada (", n_folds, "-fold):\n")
cat("   • RMSE:", sprintf("%.4f", rmse_cv), "\n")
cat("   • MAE:", sprintf("%.4f", mae_cv), "\n")
cat("   • MAPE:", sprintf("%.2f%%", mape_cv), "\n")
cat("   • R²:", sprintf("%.4f", r2_cv), "\n\n")

cat("Interpretación:\n")
if(r2_cv > 0.7) {
  cat("   ✓ El modelo tiene EXCELENTE capacidad predictiva\n")
} else if(r2_cv > 0.5) {
  cat("   ✓ El modelo tiene BUENA capacidad predictiva\n")
} else {
  cat("   • El modelo tiene capacidad predictiva MODERADA\n")
}

cat("\n================================================================================\n")
cat("7. CLASIFICACIÓN DE ZONAS\n")
cat("================================================================================\n\n")

print(tabla_zonas)

cat("\n\nZonas Prioritarias (Bajo Precio - Posibles barreras de mercado):\n\n")
print(zonas_prioritarias)

cat("\n\nZonas de Alto Precio (Posible poder de mercado local):\n\n")
print(zonas_alto)

cat("\n================================================================================\n")
cat("8. RECOMENDACIONES DE POLÍTICA PÚBLICA\n")
cat("================================================================================\n\n")

cat("8.1 ZONAS DE BAJO PRECIO (Prioridad Alta)\n")
cat("   Hipótesis: Barreras de acceso a mercados\n")
cat("   Recomendaciones:\n")
cat("   • Inversión en infraestructura vial rural\n")
cat("   • Creación de centros de acopio estratégicos\n")
cat("   • Mejora de conectividad digital\n")
cat("   • Programas de fortalecimiento asociativo\n\n")

cat("8.2 ZONAS DE ALTO PRECIO (Prioridad Media)\n")
cat("   Hipótesis: Poder de mercado local / Concentración\n")
cat("   Recomendaciones:\n")
cat("   • Fomentar entrada de nuevos compradores\n")
cat("   • Promover asociatividad de productores\n")
cat("   • Implementar sistemas de información de precios\n\n")

cat("8.3 ALTA VARIABILIDAD ESPACIAL\n")
cat("   Hipótesis: Mercados fragmentados / Información asimétrica\n")
cat("   Recomendaciones:\n")
cat("   • Plataforma nacional de precios en tiempo real\n")
cat("   • Capacitación en negociación y comercialización\n")
cat("   • Fortalecer redes de productores\n\n")

cat("================================================================================\n")
cat("9. CONTRIBUCIONES DEL ESTUDIO\n")
cat("================================================================================\n\n")

cat("9.1 Metodológicas:\n")
cat("   • Primera aplicación de modelos de rango reducido a precios\n")
cat("     agropecuarios en Perú\n")
cat("   • Reducción de complejidad computacional de O(n³) a O(nm²)\n")
cat("   • Métricas de integración espacial de mercados\n\n")

cat("9.2 Empíricas:\n")
cat("   • Caracterización de disparidades espaciales a nivel nacional\n")
cat("   • Cuantificación de barreras de mercado\n")
cat("   • Identificación de", nrow(zonas_prioritarias), 
    "zonas prioritarias\n\n")

cat("9.3 Política Pública:\n")
cat("   • Herramienta para focalización geográfica de programas\n")
cat("   • Evidencia para diseño de políticas de infraestructura\n")
cat("   • Sistema de monitoreo de integración de mercados\n\n")

cat("================================================================================\n")
cat("10. ARCHIVOS GENERADOS\n")
cat("================================================================================\n\n")

cat("Gráficos:\n")
cat("   01_histograma_precios.png\n")
cat("   02_boxplot_regiones.png\n")
cat("   03_mapa_espacial.png\n")
cat("   04_mapa_promedios.png\n")
cat("   05_variograma.png\n")
cat("   06_diagnostico_mcmc.png\n")
cat("   07_mapa_prediccion.png\n")
cat("   08_mapa_incertidumbre.png\n")
cat("   09_mapa_ic_amplitud.png\n")
cat("   10_mapa_clasificacion_zonas.png\n")
cat("   11_validacion_cruzada.png\n\n")

cat("Datos:\n")
cat("   workspace_analisis_espacial.RData\n")
cat("   zonas_prioritarias_bajo_precio.csv\n")
cat("   zonas_alto_precio.csv\n")
cat("   REPORTE_COMPLETO.txt\n\n")

cat("================================================================================\n")
cat("11. CONCLUSIONES\n")
cat("================================================================================\n\n")

cat("1. Se identificó heterogeneidad espacial significativa con dispersión\n")
cat("   del", round(estadisticas$dispersion, 1), "% en precios de derivados agropecuarios.\n\n")

cat("2. El modelo spNNGP demostró", 
    ifelse(r2_cv > 0.6, "excelente", "buena"), 
    "capacidad predictiva (R² =", round(r2_cv, 3), ").\n\n")

cat("3. Los mercados presentan", 
    ifelse(indice_integracion > 2, "alta", 
           ifelse(indice_integracion > 1, "moderada", "baja")),
    "integración espacial.\n\n")

cat("4. Se identificaron", nrow(zonas_prioritarias), 
    "zonas prioritarias para intervención.\n\n")

cat("5. La reducción de rango permitió análisis factible con", n_obs, 
    "ubicaciones\n   en", round(tiempo_total, 1), "minutos vs.", 
    round(tiempo_total * (n_obs^3) / (n_obs * 15^2) / 60, 1), 
    "horas estimadas con GP completo.\n\n")

cat("================================================================================\n")
cat("FIN DEL REPORTE\n")
cat("================================================================================\n")
cat("\nGenerado:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")

sink()

cat("\n✓ Reporte completo guardado en 'REPORTE_COMPLETO.txt'\n")

# ==============================================================================
# 18. RESUMEN DE RESULTADOS EN PANTALLA
# ==============================================================================

cat("\n")
cat("================================================================================\n")
cat("                    ANÁLISIS COMPLETADO EXITOSAMENTE\n")
cat("================================================================================\n\n")

cat("RESUMEN DE HALLAZGOS PRINCIPALES:\n\n")

cat("1. DATOS PROCESADOS\n")
cat("   ✓", nrow(datos_limpios), "observaciones analizadas\n")
cat("   ✓", n_obs, "ubicaciones únicas\n")
cat("   ✓", n_distinct(datos_espaciales$NOMBDEDO), "departamentos\n\n")

cat("2. HETEROGENEIDAD ESPACIAL\n")
cat("   ✓ Precio medio: S/", sprintf("%.2f", estadisticas$media), "\n")
cat("   ✓ Dispersión:", sprintf("%.1f%%", estadisticas$dispersion), "\n")
cat("   ✓ Coef. Variación:", sprintf("%.1f%%", estadisticas$cv), "\n\n")

cat("3. AUTOCORRELACIÓN ESPACIAL\n")
cat("   ✓ Índice de Moran:", sprintf("%.4f", moran_resultado$estimate[1]), "\n")
cat("   ✓ P-value:", format.pval(moran_resultado$p.value), "\n")
cat("   ✓ Significancia:", ifelse(moran_resultado$p.value < 0.05, "SÍ", "NO"), "\n\n")

cat("4. MODELO spNNGP\n")
cat("   ✓ Phi (range):", sprintf("%.4f", phi_mediana), "\n")
cat("   ✓ Rango efectivo:", sprintf("%.2f", rango_efectivo), "grados (≈", 
    sprintf("%.0f", rango_efectivo * 111), "km)\n")
cat("   ✓ Varianza espacial:", sprintf("%.1f%%", prop_espacial * 100), "\n")
cat("   ✓ Tiempo de ejecución:", round(tiempo_total, 2), "minutos\n\n")

cat("5. VALIDACIÓN\n")
cat("   ✓ RMSE:", sprintf("%.4f", rmse_cv), "\n")
cat("   ✓ R²:", sprintf("%.4f", r2_cv), "\n")
cat("   ✓ Calidad predictiva:", 
    ifelse(r2_cv > 0.7, "EXCELENTE", ifelse(r2_cv > 0.5, "BUENA", "MODERADA")), "\n\n")

cat("6. INTEGRACIÓN DE MERCADOS\n")
cat("   ✓ Índice:", sprintf("%.2f", indice_integracion), "\n")
cat("   ✓ Estado:", 
    ifelse(indice_integracion > 2, "ALTA INTEGRACIÓN", 
           ifelse(indice_integracion > 1, "MODERADA", "BAJA/FRAGMENTADA")), "\n\n")

cat("7. ZONAS IDENTIFICADAS\n")
cat("   ✓", nrow(zonas_prioritarias), "zonas de bajo precio (prioritarias)\n")
cat("   ✓", nrow(zonas_alto), "zonas de alto precio\n\n")

cat("8. ARCHIVOS GENERADOS\n")
cat("   ✓ 11 gráficos en formato PNG\n")
cat("   ✓ 1 workspace RData\n")
cat("   ✓ 2 archivos CSV con zonas\n")
cat("   ✓ 1 reporte completo TXT\n\n")

cat("================================================================================\n")
cat("                         RECOMENDACIONES FINALES\n")
cat("================================================================================\n\n")

cat("Para MIDAGRI y formuladores de política:\n\n")

cat("1. INTERVENCIÓN INMEDIATA (Zonas de bajo precio)\n")
cat("   • Departamentos prioritarios identificados\n")
cat("   • Requieren mejora de infraestructura vial\n")
cat("   • Implementar centros de acopio\n\n")

cat("2. REGULACIÓN Y COMPETENCIA (Zonas de alto precio)\n")
cat("   • Evaluar concentración de mercado\n")
cat("   • Promover entrada de nuevos actores\n")
cat("   • Fortalecer asociatividad productores\n\n")

cat("3. INFORMACIÓN Y TRANSPARENCIA\n")
cat("   • Sistema nacional de precios en tiempo real\n")
cat("   • Plataforma de acceso público\n")
cat("   • Capacitación en uso de información\n\n")

cat("4. MONITOREO CONTINUO\n")
cat("   • Actualizar análisis trimestralmente\n")
cat("   • Evaluar impacto de intervenciones\n")
cat("   • Ajustar estrategias según evidencia\n\n")

cat("================================================================================\n\n")

# ==============================================================================
# 19. ANÁLISIS ADICIONAL: HOTSPOT ANALYSIS (Getis-Ord Gi*)
# ==============================================================================

cat("=== ANÁLISIS DE HOTSPOTS (Getis-Ord Gi*) ===\n")

# Calcular Getis-Ord Gi*
datos_espaciales$gi_star <- localG(datos_espaciales$precio_medio, listw)

# Clasificar hotspots
datos_espaciales <- datos_espaciales %>%
  mutate(
    hotspot_tipo = case_when(
      gi_star > 2.58 ~ "Hot Spot (99%)",
      gi_star > 1.96 ~ "Hot Spot (95%)",
      gi_star > 1.65 ~ "Hot Spot (90%)",
      gi_star < -2.58 ~ "Cold Spot (99%)",
      gi_star < -1.96 ~ "Cold Spot (95%)",
      gi_star < -1.65 ~ "Cold Spot (90%)",
      TRUE ~ "No significativo"
    )
  )

# Resumen de hotspots
tabla_hotspots <- datos_espaciales %>%
  group_by(hotspot_tipo) %>%
  summarise(
    n = n(),
    precio_promedio = mean(precio_medio),
    .groups = "drop"
  )

cat("\n--- ANÁLISIS DE CLUSTERS ESPACIALES (Gi*) ---\n")
print(tabla_hotspots)

# Mapa de hotspots
p_hotspots <- ggplot(datos_espaciales, aes(x = longitud, y = latitud, color = hotspot_tipo)) +
  geom_point(size = 3, alpha = 0.8) +
  scale_color_manual(
    values = c(
      "Hot Spot (99%)" = "#8B0000",
      "Hot Spot (95%)" = "#DC143C",
      "Hot Spot (90%)" = "#FF6347",
      "Cold Spot (99%)" = "#00008B",
      "Cold Spot (95%)" = "#4169E1",
      "Cold Spot (90%)" = "#87CEEB",
      "No significativo" = "#D3D3D3"
    ),
    name = "Clasificación"
  ) +
  labs(
    title = "Análisis de Hotspots - Getis-Ord Gi*",
    subtitle = "Clusters de precios altos (hot) y bajos (cold)",
    x = "Longitud",
    y = "Latitud",
    caption = "Hot spots: agrupación de precios altos | Cold spots: agrupación de precios bajos"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(color = "gray40"),
    legend.position = "right"
  )

ggsave("12_mapa_hotspots.png", p_hotspots, width = 14, height = 10, dpi = 300)

cat("✓ Mapa de hotspots guardado\n")

# ==============================================================================
# 20. TABLA RESUMEN PARA PUBLICACIÓN
# ==============================================================================

cat("\n=== GENERANDO TABLAS PARA PUBLICACIÓN ===\n")

# Tabla 1: Estadísticas por región
tabla1 <- stats_region %>%
  mutate(across(where(is.numeric), ~round(., 2))) %>%
  rename(
    Región = REGION,
    N = n,
    `N Ubicaciones` = n_ubigeos,
    `Precio Medio` = media,
    `Desv. Est.` = desv_est,
    Mínimo = minimo,
    Máximo = maximo,
    `CV (%)` = cv
  )

write.csv(tabla1, "tabla1_estadisticas_region.csv", row.names = FALSE)

# Tabla 2: Parámetros del modelo
tabla2 <- data.frame(
  Parámetro = c("Phi (φ)", "Sigma² (σ²)", "Tau² (τ²)", "Rango Efectivo", 
                "Prop. Varianza Espacial"),
  Estimación = c(
    sprintf("%.4f", phi_mediana),
    sprintf("%.4f", sigma2_med),
    sprintf("%.4f", tau2_med),
    sprintf("%.2f grados (%.0f km)", rango_efectivo, rango_efectivo * 111),
    sprintf("%.1f%%", prop_espacial * 100)
  ),
  IC_95_Inferior = c(
    sprintf("%.4f", quantile(samples[, "phi"], 0.025)),
    sprintf("%.4f", quantile(samples[, "sigma.sq"], 0.025)),
    sprintf("%.4f", quantile(samples[, "tau.sq"], 0.025)),
    "-",
    "-"
  ),
  IC_95_Superior = c(
    sprintf("%.4f", quantile(samples[, "phi"], 0.975)),
    sprintf("%.4f", quantile(samples[, "sigma.sq"], 0.975)),
    sprintf("%.4f", quantile(samples[, "tau.sq"], 0.975)),
    "-",
    "-"
  )
)

write.csv(tabla2, "tabla2_parametros_modelo.csv", row.names = FALSE)

# Tabla 3: Métricas de validación
tabla3 <- data.frame(
  Métrica = c("RMSE", "MAE", "MAPE", "R²", "Tiempo Ejecución"),
  Valor = c(
    sprintf("%.4f", rmse_cv),
    sprintf("%.4f", mae_cv),
    sprintf("%.2f%%", mape_cv),
    sprintf("%.4f", r2_cv),
    sprintf("%.2f minutos", tiempo_total)
  ),
  Interpretación = c(
    "Error cuadrático medio",
    "Error absoluto medio",
    "Error porcentual",
    ifelse(r2_cv > 0.7, "Excelente ajuste", 
           ifelse(r2_cv > 0.5, "Buen ajuste", "Ajuste moderado")),
    sprintf("%.0fx más rápido que GP completo", 
            (n_obs^3) / (n_obs * 15^2))
  )
)

write.csv(tabla3, "tabla3_metricas_validacion.csv", row.names = FALSE)

cat("✓ Tablas para publicación guardadas\n")

# ==============================================================================
# 21. CREAR SCRIPT DE VISUALIZACIÓN INTERACTIVA
# ==============================================================================

cat("\n=== CREANDO SCRIPT DE VISUALIZACIÓN INTERACTIVA ===\n")

script_interactivo <- '
# Script de Visualización Interactiva
# Ejecutar después del análisis principal

library(leaflet)
library(htmlwidgets)

# Cargar workspace
load("workspace_analisis_espacial.RData")

# Crear mapa interactivo con leaflet
mapa_interactivo <- leaflet(datos_espaciales) %>%
  addProviderTiles(providers$CartoDB.Positron) %>%
  addCircleMarkers(
    lng = ~longitud,
    lat = ~latitud,
    radius = ~sqrt(precio_medio) * 2,
    color = ~colorQuantile("YlOrRd", precio_medio)(precio_medio),
    fillOpacity = 0.7,
    popup = ~paste0(
      "<b>Ubicación:</b> ", NOMBDEDO, "<br>",
      "<b>Región:</b> ", REGION, "<br>",
      "<b>Precio Medio:</b> S/ ", round(precio_medio, 2), "<br>",
      "<b>N Obs:</b> ", n_obs
    )
  ) %>%
  addLegend(
    "bottomright",
    pal = colorQuantile("YlOrRd", datos_espaciales$precio_medio),
    values = ~precio_medio,
    title = "Precio (S/)",
    opacity = 0.7
  )

# Guardar mapa
saveWidget(mapa_interactivo, "mapa_interactivo.html")

cat("Mapa interactivo guardado en mapa_interactivo.html\n")
'

writeLines(script_interactivo, "script_mapa_interactivo.R")

cat("✓ Script de visualización guardado en 'script_mapa_interactivo.R'\n")

# ==============================================================================
# 22. MENSAJE FINAL
# ==============================================================================

cat("\n")
cat("================================================================================\n")
cat("                           ¡ANÁLISIS FINALIZADO!\n")
cat("================================================================================\n\n")

cat("Todos los resultados han sido generados exitosamente.\n\n")

cat("PRÓXIMOS PASOS SUGERIDOS:\n\n")

cat("1. Revisar el archivo 'REPORTE_COMPLETO.txt' para el resumen detallado\n\n")

cat("2. Analizar los 12 gráficos generados:\n")
cat("   • Exploratorios (01-04)\n")
cat("   • Variograma (05)\n")
cat("   • Diagnóstico MCMC (06)\n")
cat("   • Mapas predictivos (07-10)\n")
cat("   • Validación (11)\n")
cat("   • Hotspots (12)\n\n")

cat("3. Revisar las zonas prioritarias:\n")
cat("   • zonas_prioritarias_bajo_precio.csv\n")
cat("   • zonas_alto_precio.csv\n\n")

cat("4. Para visualización interactiva:\n")
cat("   source('script_mapa_interactivo.R')\n\n")

cat("5. Para recuperar el análisis:\n")
cat("   load('workspace_analisis_espacial.RData')\n\n")

cat("================================================================================\n")
cat("                     REFERENCIAS BIBLIOGRÁFICAS\n")
cat("================================================================================\n\n")

cat("[1] Banerjee, S., Carlin, B.P., & Gelfand, A.E. (2014).\n")
cat("    Hierarchical Modeling and Analysis for Spatial Data.\n\n")

cat("[2] Finley, A.O., Datta, A., & Banerjee, S. (2020).\n")
cat("    spNNGP R package for nearest neighbor Gaussian process models.\n\n")

cat("[3] Cressie, N. (1993). Statistics for Spatial Data.\n\n")

cat("[4] World Bank (2019). Gaining momentum in Peruvian agriculture.\n\n")

cat("================================================================================\n\n")

cat("Análisis realizado por: Luz Bella Valenzuela Narvaez\n")
cat("Universidad Nacional del Altiplano\n")
cat("Curso: Estadística Espacial\n")
cat("Docente: Ing. Fred Torres Cruz\n")
cat("Fecha:", format(Sys.Date(), "%d de %B de %Y"), "\n\n")

cat("Para consultas o soporte, revisar la documentación de los paquetes:\n")
cat("• spNNGP: https://cran.r-project.org/package=spNNGP\n")
cat("• geoR: https://cran.r-project.org/package=geoR\n")
cat("• spdep: https://cran.r-project.org/package=spdep\n\n")

cat("================================================================================\n")
cat("                              FIN DEL SCRIPT\n")
cat("================================================================================\n")

# Guardar información de sesión
sink("session_info.txt")
cat("INFORMACIÓN DE LA SESIÓN R\n")
cat("==========================\n\n")
print(sessionInfo())
sink()

cat("\n✓ Información de sesión guardada en 'session_info.txt'\n")
cat("\n¡Análisis completado exitosamente! Todos los archivos han sido generados.\n\n") = "bold", size = 14),
plot.subtitle = element_text(color = "gray40"),
panel.grid.minor = element_blank()
)

ggsave("01_histograma_precios.png", p1, width = 12, height = 7, dpi = 300)

# 6.2 Boxplot por región
if(tiene_region) {
  p2 <- ggplot(datos_limpios, aes(x = reorder(REGION, precio, FUN = median), 
                                  y = precio, fill = REGION)) +
    geom_boxplot(outlier.alpha = 0.3, show.legend = FALSE) +
    scale_fill_viridis_d(option = "plasma") +
    labs(
      title = "Distribución de Precios por Región Natural",
      x = "Región",
      y = "Precio (S/ por unidad)"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold"),
      axis.text.x = element_text(angle = 45, hjust = 1)
    ) +
    coord_flip()
  
  ggsave("02_boxplot_regiones.png", p2, width = 12, height = 7, dpi = 300)
  cat("✓ Boxplot por región guardado\n")
} else {
  cat("⚠ Saltando boxplot por región (columna no disponible)\n")
}

# 6.3 Mapa de dispersión espacial
p3 <- ggplot(datos_limpios, aes(x = longitud, y = latitud, color = precio)) +
  geom_point(alpha = 0.6, size = 2.5) +
  scale_color_viridis(option = "plasma", name = "Precio\n(S/)") +
  labs(
    title = "Distribución Espacial de Precios en Perú",
    subtitle = "Cada punto representa una ubicación con observaciones",
    x = "Longitud",
    y = "Latitud"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    legend.position = "right",
    panel.grid = element_line(color = "gray90")
  )

ggsave("03_mapa_espacial.png", p3, width = 12, height = 9, dpi = 300)
cat("✓ Mapa espacial guardado\n")

# 6.4 Precios promedio por departamento (mapa de calor)
if(tiene_nombdedo) {
  precios_depto <- datos_limpios %>%
    group_by(NOMBDEDO, latitud, longitud) %>%
    summarise(precio_medio = mean(precio, na.rm = TRUE), .groups = "drop")
  
  p4 <- ggplot(precios_depto, aes(x = longitud, y = latitud, 
                                  size = precio_medio, color = precio_medio)) +
    geom_point(alpha = 0.7) +
    scale_color_viridis(option = "turbo", name = "Precio\nPromedio") +
    scale_size_continuous(name = "Precio\nPromedio", range = c(3, 15)) +
    labs(
      title = "Precios Promedio por Departamento",
      x = "Longitud",
      y = "Latitud"
    ) +
    theme_minimal() +
    theme(plot.title = element_text(face = "bold"))
  
  ggsave("04_mapa_promedios.png", p4, width = 12, height = 9, dpi = 300)
} else {
  # Versión alternativa sin departamento
  precios_ubigeo <- datos_limpios %>%
    group_by(UBIGEO, latitud, longitud) %>%
    summarise(precio_medio = mean(precio, na.rm = TRUE), .groups = "drop")
  
  p4 <- ggplot(precios_ubigeo, aes(x = longitud, y = latitud, 
                                   size = precio_medio, color = precio_medio)) +
    geom_point(alpha = 0.7) +
    scale_color_viridis(option = "turbo", name = "Precio\nPromedio") +
    scale_size_continuous(name = "Precio\nPromedio", range = c(3, 15)) +
    labs(
      title = "Precios Promedio por Ubicación",
      x = "Longitud",
      y = "Latitud"
    ) +
    theme_minimal() +
    theme(plot.title = element_text(face = "bold"))
  
  ggsave("04_mapa_promedios.png", p4, width = 12, height = 9, dpi = 300)
  cat("✓ Mapa de promedios guardado\n")
}

cat("\n✓ Gráficos exploratorios completados\n")

# ==============================================================================
# 7. ANÁLISIS ESPACIAL EXPLORATORIO
# ==============================================================================

cat("\n=== ANÁLISIS ESPACIAL EXPLORATORIO ===\n")

# 7.1 Preparar datos para análisis espacial
# Usar datos agregados por ubicación para evitar duplicados
if(tiene_region & tiene_nombdedo) {
  datos_espaciales <- datos_limpios %>%
    group_by(UBIGEO, latitud, longitud, REGION, NOMBDEDO) %>%
    summarise(
      precio_medio = mean(precio, na.rm = TRUE),
      n_obs = n(),
      .groups = "drop"
    ) %>%
    filter(!is.na(latitud), !is.na(longitud))
} else if(tiene_region) {
  datos_espaciales <- datos_limpios %>%
    group_by(UBIGEO, latitud, longitud, REGION) %>%
    summarise(
      precio_medio = mean(precio, na.rm = TRUE),
      n_obs = n(),
      .groups = "drop"
    ) %>%
    filter(!is.na(latitud), !is.na(longitud))
} else if(tiene_nombdedo) {
  datos_espaciales <- datos_limpios %>%
    group_by(UBIGEO, latitud, longitud, NOMBDEDO) %>%
    summarise(
      precio_medio = mean(precio, na.rm = TRUE),
      n_obs = n(),
      .groups = "drop"
    ) %>%
    filter(!is.na(latitud), !is.na(longitud))
} else {
  datos_espaciales <- datos_limpios %>%
    group_by(UBIGEO, latitud, longitud) %>%
    summarise(
      precio_medio = mean(precio, na.rm = TRUE),
      n_obs = n(),
      .groups = "drop"
    ) %>%
    filter(!is.na(latitud), !is.na(longitud))
}

coords <- as.matrix(datos_espaciales[, c("longitud", "latitud")])

cat("Ubicaciones únicas para análisis espacial:", nrow(datos_espaciales), "\n")

# 7.2 Matriz de distancias
dist_matrix <- as.matrix(dist(coords))
cat("Distancia media entre ubicaciones:", round(mean(dist_matrix), 2), "grados\n")
cat("Distancia máxima:", round(max(dist_matrix), 2), "grados\n")

# 7.3 Índice de Moran (autocorrelación espacial)
cat("\nCalculando Índice de Moran...\n")

# Crear matriz de vecinos (k-nearest neighbors)
k <- min(8, nrow(coords) - 1)
nb <- knn2nb(knearneigh(coords, k = k))
listw <- nb2listw(nb, style = "W")

# Test de Moran
moran_resultado <- moran.test(datos_espaciales$precio_medio, listw)

cat("\n--- ÍNDICE DE MORAN ---\n")
cat("Moran I statistic:", round(moran_resultado$estimate[1], 4), "\n")
cat("Expectativa:", round(moran_resultado$estimate[2], 4), "\n")
cat("Varianza:", round(moran_resultado$estimate[3], 6), "\n")
cat("P-value:", format.pval(moran_resultado$p.value, digits = 4), "\n")

if(moran_resultado$p.value < 0.05) {
  cat("\n✓ HAY AUTOCORRELACIÓN ESPACIAL SIGNIFICATIVA\n")
  cat("  Los precios cercanos tienden a ser similares\n")
} else {
  cat("\n✗ No hay evidencia de autocorrelación espacial\n")
}

# ==============================================================================
# 8. VARIOGRAMA EMPÍRICO
# ==============================================================================

cat("\n=== ANÁLISIS VARIOGRÁFICO ===\n")

# Crear objeto geodata
geodata <- as.geodata(
  data.frame(
    coords = coords,
    precio = datos_espaciales$precio_medio
  ),
  coords.col = 1:2,
  data.col = 3
)

# Calcular variograma empírico
cat("Calculando variograma empírico...\n")
max_dist <- max(dist_matrix) / 3
vario_emp <- variog(geodata, max.dist = max_dist, uvec = 20)

# Ajustar modelos de variograma
cat("Ajustando modelos teóricos...\n")

# Valores iniciales
nugget_ini <- var(datos_espaciales$precio_medio) * 0.1
sill_ini <- var(datos_espaciales$precio_medio) * 0.9
range_ini <- max_dist / 3

# Modelo Esférico
vario_esf <- variofit(vario_emp, 
                      ini.cov.pars = c(sill_ini, range_ini),
                      cov.model = "spherical",
                      nugget = nugget_ini,
                      weights = "equal")

# Modelo Exponencial
vario_exp <- variofit(vario_emp,
                      ini.cov.pars = c(sill_ini, range_ini),
                      cov.model = "exponential",
                      nugget = nugget_ini,
                      weights = "equal")

# Modelo Matérn
vario_matern <- variofit(vario_emp,
                         ini.cov.pars = c(sill_ini, range_ini),
                         cov.model = "matern",
                         kappa = 1.5,
                         nugget = nugget_ini,
                         weights = "equal")

cat("\n--- PARÁMETROS ESTIMADOS (Modelo Matérn) ---\n")
cat("Nugget (τ²):", round(vario_matern$nugget, 4), "\n")
cat("Sill parcial (σ²):", round(vario_matern$cov.pars[1], 4), "\n")
cat("Range (φ):", round(vario_matern$cov.pars[2], 4), "grados\n")
cat("Kappa (ν):", vario_matern$kappa, "\n")
cat("Sill total:", round(vario_matern$nugget + vario_matern$cov.pars[1], 4), "\n")

# Guardar gráfico de variograma
png("05_variograma.png", width = 12, height = 8, units = "in", res = 300)
plot(vario_emp, 
     main = "Variograma Empírico y Modelos Ajustados",
     xlab = "Distancia (grados)", 
     ylab = "Semivarianza",
     pch = 19, cex = 1.2)
lines(vario_esf, col = "#2E86AB", lwd = 2.5)
lines(vario_exp, col = "#A23B72", lwd = 2.5)
lines(vario_matern, col = "#F18F01", lwd = 2.5)
legend("bottomright", 
       legend = c("Empírico", "Esférico", "Exponencial", "Matérn"),
       col = c("black", "#2E86AB", "#A23B72", "#F18F01"),
       pch = c(19, NA, NA, NA),
       lty = c(NA, 1, 1, 1),
       lwd = c(NA, 2.5, 2.5, 2.5),
       cex = 1.1,
       bg = "white")
dev.off()

cat("✓ Variograma guardado\n")

# ==============================================================================
# 9. MODELO spNNGP (NEAREST NEIGHBOR GAUSSIAN PROCESS)
# ==============================================================================

cat("\n=== MODELO spNNGP ===\n")
cat("Este proceso puede tomar varios minutos...\n\n")

# Preparar datos para spNNGP
n_obs <- nrow(datos_espaciales)
coords_std <- scale(coords)
y_modelo <- datos_espaciales$precio_medio

cat("Configuración del modelo:\n")
cat("  N observaciones:", n_obs, "\n")
cat("  N vecinos (m):", 15, "\n")
cat("  Iteraciones MCMC:", 3000, "\n")
cat("  Burn-in:", 500, "\n\n")

# Parámetros iniciales
phi_ini <- 3 / mean(dist_matrix[upper.tri(dist_matrix)])
sigma2_ini <- var(y_modelo) * 0.7
tau2_ini <- var(y_modelo) * 0.3

starting <- list(
  "phi" = phi_ini, 
  "sigma.sq" = sigma2_ini, 
  "tau.sq" = tau2_ini
)

tuning <- list("phi" = 0.1, "sigma.sq" = 0.05, "tau.sq" = 0.05)

priors <- list(
  "phi.Unif" = c(phi_ini * 0.1, phi_ini * 10), 
  "sigma.sq.IG" = c(2, sigma2_ini),
  "tau.sq.IG" = c(2, tau2_ini)
)

# Ajustar modelo
cat("Iniciando MCMC...\n")
tiempo_inicio <- Sys.time()

modelo_nngp <- spNNGP(
  y_modelo ~ 1,
  coords = coords_std,
  starting = starting,
  method = "response",
  n.neighbors = 15,
  tuning = tuning,
  priors = priors,
  cov.model = "exponential",
  n.samples = 3000,
  n.omp.threads = parallel::detectCores() - 1,
  verbose = TRUE,
  n.report = 500
)

tiempo_fin <- Sys.time()
tiempo_total <- as.numeric(difftime(tiempo_fin, tiempo_inicio, units = "mins"))

cat("\n✓ Modelo ajustado exitosamente\n")
cat("  Tiempo de ejecución:", round(tiempo_total, 2), "minutos\n")

# Análisis de resultados
burn_in <- 500
samples <- modelo_nngp$p.theta.samples[-(1:burn_in), ]

cat("\n--- ESTIMACIONES POSTERIORES ---\n")
resumen_params <- data.frame(
  Parametro = c("phi", "sigma²", "tau²"),
  Media = c(mean(samples[, "phi"]), 
            mean(samples[, "sigma.sq"]),
            mean(samples[, "tau.sq"])),
  Mediana = c(median(samples[, "phi"]),
              median(samples[, "sigma.sq"]),
              median(samples[, "tau.sq"])),
  SD = c(sd(samples[, "phi"]),
         sd(samples[, "sigma.sq"]),
         sd(samples[, "tau.sq"])),
  Q2.5 = c(quantile(samples[, "phi"], 0.025),
           quantile(samples[, "sigma.sq"], 0.025),
           quantile(samples[, "tau.sq"], 0.025)),
  Q97.5 = c(quantile(samples[, "phi"], 0.975),
            quantile(samples[, "sigma.sq"], 0.975),
            quantile(samples[, "tau.sq"], 0.975))
)
print(resumen_params)

# Gráficos de diagnóstico
png("06_diagnostico_mcmc.png", width = 14, height = 10, units = "in", res = 300)
par(mfrow = c(3, 2), mar = c(4, 4, 2, 1))

# Trazas
plot(samples[, "phi"], type = "l", col = "#2E86AB",
     main = "Traza de Phi (range)", ylab = "Phi", xlab = "Iteración")
abline(h = median(samples[, "phi"]), col = "red", lty = 2, lwd = 2)

plot(samples[, "sigma.sq"], type = "l", col = "#A23B72",
     main = "Traza de Sigma²", ylab = "Sigma²", xlab = "Iteración")
abline(h = median(samples[, "sigma.sq"]), col = "red", lty = 2, lwd = 2)

plot(samples[, "tau.sq"], type = "l", col = "#F18F01",
     main = "Traza de Tau²", ylab = "Tau²", xlab = "Iteración")
abline(h = median(samples[, "tau.sq"]), col = "red", lty = 2, lwd = 2)

# Histogramas
hist(samples[, "phi"], breaks = 30, col = "#2E86AB", border = "white",
     main = "Distribución Posterior de Phi", xlab = "Phi", freq = FALSE)
abline(v = median(samples[, "phi"]), col = "red", lwd = 2, lty = 2)

hist(samples[, "sigma.sq"], breaks = 30, col = "#A23B72", border = "white",
     main = "Distribución Posterior de Sigma²", xlab = "Sigma²", freq = FALSE)
abline(v = median(samples[, "sigma.sq"]), col = "red", lwd = 2, lty = 2)

hist(samples[, "tau.sq"], breaks = 30, col = "#F18F01", border = "white",
     main = "Distribución Posterior de Tau²", xlab = "Tau²", freq = FALSE)
abline(v = median(samples[, "tau.sq"]), col = "red", lwd = 2, lty = 2)

dev.off()
cat("✓ Gráficos de diagnóstico guardados\n")

# ==============================================================================
# 10. PREDICCIÓN ESPACIAL (KRIGING)
# ==============================================================================

cat("\n=== PREDICCIÓN ESPACIAL ===\n")

# Crear grid de predicción
lon_range <- range(coords[, 1])
lat_range <- range(coords[, 2])

# Grid más fino
n_grid <- 60
lon_seq <- seq(lon_range[1], lon_range[2], length.out = n_grid)
lat_seq <- seq(lat_range[1], lat_range[2], length.out = n_grid)

grid_pred <- expand.grid(longitud = lon_seq, latitud = lat_seq)
coords_pred <- as.matrix(grid_pred)

# Estandarizar con mismos parámetros
coords_pred_std <- scale(coords_pred,
                         center = attr(coords_std, "scaled:center"),
                         scale = attr(coords_std, "scaled:scale"))

cat("Grid de predicción:", nrow(grid_pred), "puntos\n")
cat("Realizando predicción...\n")

# Predicción
pred_nngp <- predict(
  modelo_nngp,
  X.0 = matrix(1, nrow = nrow(coords_pred_std), ncol = 1),
  coords.0 = coords_pred_std,
  n.omp.threads = parallel::detectCores() - 1
)

# Extraer estadísticos
grid_pred$pred_precio <- apply(pred_nngp$p.y.0, 1, mean)
grid_pred$pred_sd <- apply(pred_nngp$p.y.0, 1, sd)
grid_pred$pred_q025 <- apply(pred_nngp$p.y.0, 1, quantile, 0.025)
grid_pred$pred_q975 <- apply(pred_nngp$p.y.0, 1, quantile, 0.975)

cat("✓ Predicción completada\n")

# ==============================================================================
# 11. MAPAS PREDICTIVOS
# ==============================================================================

cat("\n=== GENERANDO MAPAS PREDICTIVOS ===\n")

# 11.1 Mapa de precios predichos
p_pred <- ggplot() +
  geom_raster(data = grid_pred, 
              aes(x = longitud, y = latitud, fill = pred_precio)) +
  geom_point(data = datos_espaciales, 
             aes(x = longitud, y = latitud), 
             size = 1, alpha = 0.4, color = "white") +
  scale_fill_viridis(option = "plasma", 
                     name = "Precio\nPredicho\n(S/)") +
  labs(
    title = "Mapa Predictivo de Precios - Modelo spNNGP",
    subtitle = sprintf("Rango Efectivo: %.2f grados | N = %d ubicaciones", 
                       median(samples[, "phi"]), n_obs),
    x = "Longitud",
    y = "Latitud",
    caption = "Puntos blancos: ubicaciones observadas"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face