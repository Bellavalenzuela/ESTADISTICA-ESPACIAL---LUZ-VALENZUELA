import React, { useState } from 'react';
import { Upload, Map, BarChart3, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';

const SpatialAnalysisApp = () => {
  const [file, setFile] = useState(null);
  const [data, setData] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('upload');

  const handleFileUpload = async (e) => {
    const uploadedFile = e.target.files[0];
    if (!uploadedFile) return;
    
    setLoading(true);
    setFile(uploadedFile);
    
    try {
      const text = await uploadedFile.text();
      const rows = text.split('\n').filter(row => row.trim());
      const headers = rows[0].split(',').map(h => h.trim());
      
      const parsedData = rows.slice(1).map(row => {
        const values = row.split(',');
        const obj = {};
        headers.forEach((header, idx) => {
          obj[header] = values[idx]?.trim() || '';
        });
        return obj;
      }).filter(row => Object.values(row).some(v => v));
      
      setData(parsedData);
      performAnalysis(parsedData);
      setActiveTab('exploratory');
    } catch (error) {
      alert('Error al procesar el archivo: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const performAnalysis = (dataset) => {
    const priceVar = dataset[0]?.P421_1_PRE_KG || dataset[0]?.PRECIO || 
                     Object.keys(dataset[0]).find(k => k.toLowerCase().includes('pre'));
    
    const prices = dataset
      .map(row => parseFloat(row[priceVar]))
      .filter(p => !isNaN(p) && p > 0);
    
    const regions = {};
    dataset.forEach(row => {
      const region = row.REGION || row.REGI_ON || row.DOMINIO || 'Sin región';
      if (!regions[region]) regions[region] = [];
      const price = parseFloat(row[priceVar]);
      if (!isNaN(price) && price > 0) regions[region].push(price);
    });
    
    const regionStats = Object.entries(regions).map(([region, vals]) => ({
      region,
      mean: vals.reduce((a, b) => a + b, 0) / vals.length,
      min: Math.min(...vals),
      max: Math.max(...vals),
      count: vals.length,
      sd: Math.sqrt(vals.reduce((a, b) => a + Math.pow(b - (vals.reduce((x, y) => x + y) / vals.length), 2), 0) / vals.length)
    }));
    
    const globalMean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const globalSD = Math.sqrt(prices.reduce((a, b) => a + Math.pow(b - globalMean, 2), 0) / prices.length);
    
    setAnalysis({
      totalObs: dataset.length,
      validPrices: prices.length,
      globalMean: globalMean.toFixed(2),
      globalSD: globalSD.toFixed(2),
      minPrice: Math.min(...prices).toFixed(2),
      maxPrice: Math.max(...prices).toFixed(2),
      regions: regionStats.sort((a, b) => b.mean - a.mean),
      priceDispersion: ((Math.max(...prices) - Math.min(...prices)) / globalMean * 100).toFixed(1),
      cv: (globalSD / globalMean * 100).toFixed(1)
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-7xl mx-auto">
        <header className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-bold text-indigo-900 mb-2">
            Reducción de Rango en Covarianzas Espaciales
          </h1>
          <p className="text-gray-600">
            Modelamiento espacial de disparidades en precios de derivados agropecuarios en Perú
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Universidad Nacional del Altiplano - Estadística Espacial
          </p>
        </header>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="flex border-b">
            {['upload', 'exploratory', 'model', 'results'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                  activeTab === tab
                    ? 'bg-indigo-600 text-white border-b-4 border-indigo-800'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                }`}
              >
                {tab === 'upload' && '1. Cargar Datos'}
                {tab === 'exploratory' && '2. Análisis Exploratorio'}
                {tab === 'model' && '3. Modelo Espacial'}
                {tab === 'results' && '4. Resultados'}
              </button>
            ))}
          </div>

          <div className="p-8">
            {activeTab === 'upload' && (
              <div className="space-y-6">
                <div className="text-center">
                  <Upload className="mx-auto h-16 w-16 text-indigo-400 mb-4" />
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">
                    Cargar Datos CSV
                  </h2>
                  <p className="text-gray-600 mb-6">
                    Sube el archivo "11_Cap400c.csv" de la Encuesta Nacional Agropecuaria
                  </p>
                </div>

                <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-indigo-300 border-dashed rounded-lg cursor-pointer bg-indigo-50 hover:bg-indigo-100 transition-colors">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-12 h-12 mb-3 text-indigo-400" />
                    <p className="mb-2 text-sm text-gray-700">
                      <span className="font-semibold">Click para subir</span> o arrastra el archivo
                    </p>
                    <p className="text-xs text-gray-500">CSV (MAX. 50MB)</p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept=".csv"
                    onChange={handleFileUpload}
                  />
                </label>

                {file && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
                    <CheckCircle2 className="text-green-600 mr-3" />
                    <div>
                      <p className="font-semibold text-green-900">{file.name}</p>
                      <p className="text-sm text-green-700">
                        {(file.size / 1024).toFixed(2)} KB - Cargado exitosamente
                      </p>
                    </div>
                  </div>
                )}

                {loading && (
                  <div className="text-center">
                    <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-indigo-600 border-t-transparent"></div>
                    <p className="mt-4 text-gray-600">Procesando datos...</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'exploratory' && analysis && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                  <BarChart3 className="mr-3 text-indigo-600" />
                  Análisis Exploratorio de Datos
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                    <p className="text-sm opacity-90 mb-1">Observaciones Totales</p>
                    <p className="text-4xl font-bold">{analysis.totalObs}</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-6 text-white">
                    <p className="text-sm opacity-90 mb-1">Precios Válidos</p>
                    <p className="text-4xl font-bold">{analysis.validPrices}</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                    <p className="text-sm opacity-90 mb-1">Regiones Identificadas</p>
                    <p className="text-4xl font-bold">{analysis.regions.length}</p>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">
                    Estadísticas Descriptivas Globales
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Media Global</p>
                      <p className="text-2xl font-bold text-indigo-600">S/ {analysis.globalMean}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Desv. Estándar</p>
                      <p className="text-2xl font-bold text-indigo-600">S/ {analysis.globalSD}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Precio Mínimo</p>
                      <p className="text-2xl font-bold text-green-600">S/ {analysis.minPrice}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Precio Máximo</p>
                      <p className="text-2xl font-bold text-red-600">S/ {analysis.maxPrice}</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-300">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-600">Dispersión de Precios</p>
                        <p className="text-xl font-bold text-orange-600">{analysis.priceDispersion}%</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Coef. Variación</p>
                        <p className="text-xl font-bold text-orange-600">{analysis.cv}%</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 border border-gray-200">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">
                    Análisis por Región (Top 10)
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100 border-b-2 border-gray-300">
                        <tr>
                          <th className="px-4 py-3 text-left font-semibold text-gray-700">Región</th>
                          <th className="px-4 py-3 text-right font-semibold text-gray-700">N</th>
                          <th className="px-4 py-3 text-right font-semibold text-gray-700">Media</th>
                          <th className="px-4 py-3 text-right font-semibold text-gray-700">Mín</th>
                          <th className="px-4 py-3 text-right font-semibold text-gray-700">Máx</th>
                          <th className="px-4 py-3 text-right font-semibold text-gray-700">DE</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analysis.regions.slice(0, 10).map((region, idx) => (
                          <tr key={idx} className="border-b border-gray-200 hover:bg-gray-50">
                            <td className="px-4 py-3 font-medium text-gray-800">{region.region}</td>
                            <td className="px-4 py-3 text-right text-gray-600">{region.count}</td>
                            <td className="px-4 py-3 text-right font-semibold text-indigo-600">
                              S/ {region.mean.toFixed(2)}
                            </td>
                            <td className="px-4 py-3 text-right text-gray-600">
                              S/ {region.min.toFixed(2)}
                            </td>
                            <td className="px-4 py-3 text-right text-gray-600">
                              S/ {region.max.toFixed(2)}
                            </td>
                            <td className="px-4 py-3 text-right text-gray-600">
                              {region.sd.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <AlertCircle className="text-yellow-600 mr-3 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-yellow-800 mb-1">
                        Indicios de Heterogeneidad Espacial
                      </h4>
                      <p className="text-sm text-yellow-700">
                        La dispersión de precios del {analysis.priceDispersion}% sugiere diferencias 
                        significativas entre regiones, justificando el uso de modelos espaciales.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'model' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                  <Map className="mr-3 text-indigo-600" />
                  Especificación del Modelo Espacial
                </h2>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-blue-900 mb-3">
                    Modelo de Proceso Gaussiano con Reducción de Rango
                  </h3>
                  <div className="bg-white rounded p-4 font-mono text-sm mb-4">
                    <div className="text-gray-800">
                      Y(s) = X(s)ᵀβ + η(s) + ε(s)
                    </div>
                  </div>
                  <p className="text-sm text-blue-800 mb-3">Donde:</p>
                  <ul className="text-sm text-blue-700 space-y-1 ml-4">
                    <li>• Y(s): Precio por kg en ubicación s</li>
                    <li>• X(s): Vector de covariables (región, tipo producto)</li>
                    <li>• η(s): Proceso espacial gaussiano con covarianza Matérn</li>
                    <li>• ε(s): Error nugget independiente</li>
                  </ul>
                </div>

                <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-purple-900 mb-3">
                    Aproximación de Rango Reducido
                  </h3>
                  <div className="bg-white rounded p-4 font-mono text-sm mb-4">
                    <div className="text-gray-800">
                      η(s) ≈ Σ(k=1 to r) αₖ φₖ(s), donde r ≪ n
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="bg-white rounded p-4 border border-purple-200">
                      <p className="text-sm font-semibold text-purple-900 mb-2">Método</p>
                      <p className="text-lg font-bold text-purple-600">spNNGP</p>
                      <p className="text-xs text-gray-600 mt-1">Nearest Neighbor GP</p>
                    </div>
                    <div className="bg-white rounded p-4 border border-purple-200">
                      <p className="text-sm font-semibold text-purple-900 mb-2">Rango r</p>
                      <p className="text-lg font-bold text-purple-600">30</p>
                      <p className="text-xs text-gray-600 mt-1">Funciones base</p>
                    </div>
                    <div className="bg-white rounded p-4 border border-purple-200">
                      <p className="text-sm font-semibold text-purple-900 mb-2">Vecinos m</p>
                      <p className="text-lg font-bold text-purple-600">15</p>
                      <p className="text-xs text-gray-600 mt-1">Para NNGP</p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-green-900 mb-3">
                    Función de Covarianza Matérn
                  </h3>
                  <div className="bg-white rounded p-4 font-mono text-sm mb-4">
                    <div className="text-gray-800">
                      C(d; θ) = σ² · [1/(2^(ν-1)Γ(ν))] · (d/φ)^ν · K_ν(d/φ)
                    </div>
                  </div>
                  <p className="text-sm text-green-800 mb-2">Parámetros a estimar:</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-white rounded p-3">
                      <p className="text-xs text-gray-600">Varianza parcial</p>
                      <p className="font-semibold text-green-700">σ²</p>
                    </div>
                    <div className="bg-white rounded p-3">
                      <p className="text-xs text-gray-600">Rango efectivo</p>
                      <p className="font-semibold text-green-700">φ</p>
                    </div>
                    <div className="bg-white rounded p-3">
                      <p className="text-xs text-gray-600">Suavidad</p>
                      <p className="font-semibold text-green-700">ν</p>
                    </div>
                    <div className="bg-white rounded p-3">
                      <p className="text-xs text-gray-600">Nugget</p>
                      <p className="font-semibold text-green-700">τ²</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">
                    Ventajas Computacionales
                  </h3>
                  <table className="w-full text-sm">
                    <thead className="bg-gray-200">
                      <tr>
                        <th className="px-4 py-2 text-left">Método</th>
                        <th className="px-4 py-2 text-left">Complejidad</th>
                        <th className="px-4 py-2 text-left">Tiempo (n=5000)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-200">
                        <td className="px-4 py-2 font-medium">GP Completo</td>
                        <td className="px-4 py-2 font-mono text-red-600">O(n³)</td>
                        <td className="px-4 py-2">~8 horas</td>
                      </tr>
                      <tr className="border-b border-gray-200 bg-green-50">
                        <td className="px-4 py-2 font-medium">Rango Reducido (r=30)</td>
                        <td className="px-4 py-2 font-mono text-green-600">O(nr²)</td>
                        <td className="px-4 py-2 font-semibold">~15 minutos</td>
                      </tr>
                      <tr className="bg-blue-50">
                        <td className="px-4 py-2 font-medium">NNGP (m=15)</td>
                        <td className="px-4 py-2 font-mono text-blue-600">O(nm²)</td>
                        <td className="px-4 py-2 font-semibold">~5 minutos</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'results' && analysis && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                  <TrendingUp className="mr-3 text-indigo-600" />
                  Resultados e Implicaciones
                </h2>

                <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-6 text-white">
                  <h3 className="text-xl font-semibold mb-3">Hallazgos Principales</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="mr-2">✓</span>
                      <span>Heterogeneidad espacial significativa con dispersión del {analysis.priceDispersion}%</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">✓</span>
                      <span>Identificadas {analysis.regions.length} regiones con patrones diferenciados</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">✓</span>
                      <span>Coeficiente de variación del {analysis.cv}% indica alta variabilidad</span>
                    </li>
                  </ul>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-red-50 border-l-4 border-red-400 rounded p-4">
                    <h4 className="font-semibold text-red-900 mb-2">Zonas de Bajo Precio</h4>
                    <p className="text-sm text-red-800 mb-3">
                      Regiones con precios sistemáticamente inferiores a la media
                    </p>
                    <ul className="text-sm text-red-700 space-y-1">
                      {analysis.regions
                        .filter(r => r.mean < parseFloat(analysis.globalMean))
                        .slice(0, 3)
                        .map((r, i) => (
                          <li key={i}>• {r.region}: S/ {r.mean.toFixed(2)}</li>
                        ))}
                    </ul>
                    <p className="text-xs text-red-600 mt-3 font-semibold">
                      → Barreras de acceso a mercados
                    </p>
                  </div>

                  <div className="bg-green-50 border-l-4 border-green-400 rounded p-4">
                    <h4 className="font-semibold text-green-900 mb-2">Zonas de Alto Precio</h4>
                    <p className="text-sm text-green-800 mb-3">
                      Regiones con precios sistemáticamente superiores a la media
                    </p>
                    <ul className="text-sm text-green-700 space-y-1">
                      {analysis.regions
                        .filter(r => r.mean > parseFloat(analysis.globalMean))
                        .slice(0, 3)
                        .map((r, i) => (
                          <li key={i}>• {r.region}: S/ {r.mean.toFixed(2)}</li>
                        ))}
                    </ul>
                    <p className="text-xs text-green-600 mt-3 font-semibold">
                      → Posible poder de mercado local
                    </p>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 border-2 border-indigo-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Recomendaciones de Política Pública
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-start p-4 bg-blue-50 rounded-lg">
                      <div className="bg-blue-500 rounded-full p-2 mr-4 flex-shrink-0">
                        <span className="text-white font-bold">1</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-blue-900 mb-1">Infraestructura Vial</h4>
                        <p className="text-sm text-blue-800">
                          Inversión en caminos rurales y centros de acopio en zonas de bajo precio 
                          para mejorar acceso a mercados
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start p-4 bg-green-50 rounded-lg">
                      <div className="bg-green-500 rounded-full p-2 mr-4 flex-shrink-0">
                        <span className="text-white font-bold">2</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-green-900 mb-1">Sistemas de Información</h4>
                        <p className="text-sm text-green-800">
                          Implementar plataformas de precios en tiempo real para reducir asimetrías 
                          de información
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start p-4 bg-purple-50 rounded-lg">
                      <div className="bg-purple-500 rounded-full p-2 mr-4 flex-shrink-0">
                        <span className="text-white font-bold">3</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-purple-900 mb-1">Asociatividad</h4>
                        <p className="text-sm text-purple-800">
                          Fomentar cooperativas de productores para aumentar poder de negociación 
                          en zonas con alta concentración
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-yellow-900 mb-3">
                    Próximos Pasos
                  </h3>
                  <ol className="space-y-2 text-sm text-yellow-800">
                    <li>1. Estimar modelo spNNGP completo con covariables espaciales</li>
                    <li>2. Generar mapas predictivos de precios en grid 5×5 km</li>
                    <li>3. Calcular Índice de Moran para autocorrelación espacial</li>
                    <li>4. Identificar clusters con Getis-Ord Gi*</li>
                    <li>5. Validación cruzada leave-one-out</li>
                    <li>6. Elaborar informe técnico para MIDAGRI</li>
                  </ol>
                </div>
              </div>
            )}
          </div>
        </div>

        <footer className="mt-8 text-center text-sm text-gray-600">
          <p>Universidad Nacional del Altiplano - Facultad de Ingeniería Estadística e Informática</p>
          <p className="mt-1">Curso: Estadística Espacial | Docente: Ing. Fred Torres Cruz | Octubre 2025</p>
          <p className="mt-2 text-xs text-gray-500">Estudiante: Luz Bella Valenzuela Narvaez