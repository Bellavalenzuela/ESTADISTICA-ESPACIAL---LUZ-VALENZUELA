import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
from scipy.linalg import cholesky
import seaborn as sns

class GaussianRandomFieldBootstrap:
    #Inicializa el campo aleatorio gaussiano
    def __init__(self, locations, mean_func=None, cov_func=None, random_seed=None):
       
        self.locations = np.array(locations)
        self.n_points = len(locations)
        
        if random_seed:
            np.random.seed(random_seed)
        
        # Función de media por defecto: m(t) = 0
        self.mean_func = mean_func if mean_func else lambda t: 0.0
        
        # Función de covarianza por defecto: ρ(s,t) = exp(-||s-t||²/σ²)
        self.cov_func = cov_func if cov_func else self._exponential_cov
        
        # Calcular media y matriz de covarianza
        self.mean_vector = self._compute_mean_vector()
        self.cov_matrix = self._compute_covariance_matrix()
        
    def _exponential_cov(self, s, t, sigma=1.0, length_scale=1.0):
       
        distance = np.linalg.norm(np.array(s) - np.array(t))
        return sigma**2 * np.exp(-distance / length_scale)
    
    def _compute_mean_vector(self):
        
        return np.array([self.mean_func(loc) for loc in self.locations])
    
    def _compute_covariance_matrix(self):
       
        n = self.n_points
        cov_matrix = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                cov_matrix[i, j] = self.cov_func(self.locations[i], self.locations[j])
        
        return cov_matrix
    # Creación del campo aleatorio gaussiano
    # Para ello se usa descomposición de Cholesky para mantener la estructura de covarianza
    def generate_realization(self):
        
        # Primero se realiza la descomposición de Cholesky
        try:
            L = cholesky(self.cov_matrix, lower=True)
        except np.linalg.LinAlgError:
            # Si la matriz no es definida positiva, se agrega la regularización
            L = cholesky(self.cov_matrix + 1e-6 * np.eye(self.n_points), lower=True)
        
        # Generar vector aleatorio estándar
        z = np.random.standard_normal(self.n_points)
        
        # Transformación
        realization = self.mean_vector + L @ z
        return realization
    
    def bootstrap_sample(self, n_bootstrap=1000, statistic_func=None):
        
        if statistic_func is None:
            statistic_func = np.mean
        
        bootstrap_statistics = []
        bootstrap_realizations = []
        
        print(f"Generando {n_bootstrap} muestras bootstrap...")
        
        for i in range(n_bootstrap):
            # Generar realización del campo gaussiano
            realization = self.generate_realization()
            bootstrap_realizations.append(realization)
            
            # Calcular estadístico
            stat_value = statistic_func(realization)
            bootstrap_statistics.append(stat_value)
            
            if (i + 1) % 100 == 0:
                print(f"Completadas {i + 1} muestras")
        
        return np.array(bootstrap_statistics), np.array(bootstrap_realizations)
    
    def confidence_intervals(self, bootstrap_stats, confidence_level=0.95):
        """Cálculo de intervalos de confianza usando percentiles"""
        alpha = 1 - confidence_level
        lower_percentile = (alpha/2) * 100
        upper_percentile = (1 - alpha/2) * 100
        
        lower_bound = np.percentile(bootstrap_stats, lower_percentile)
        upper_bound = np.percentile(bootstrap_stats, upper_percentile)
        
        return lower_bound, upper_bound

# Ejemplo de uso
def ejemplo_bootstrap_2d():
    """Ejemplo con campo aleatorio en 2D"""
    print(" Ejemplo: Bootstrap de Campo Aleatorio Gaussiano 2D \n")
    
    # Crear grilla de puntos 2D
    x = np.linspace(0, 2, 10)
    y = np.linspace(0, 2, 10)
    locations = [(xi, yi) for xi in x for yi in y]
    
    # Función de media personalizada: m(t) = t[0] + 0.5*t[1]
    def mean_function(t):
        return t[0] + 0.5 * t[1]
    
    # Función de covarianza Matérn
    def matern_cov(s, t, sigma=1.0, length_scale=0.5, nu=1.5):
        distance = np.linalg.norm(np.array(s) - np.array(t))
        if distance == 0:
            return sigma**2
        else:
            scaled_dist = np.sqrt(2 * nu) * distance / length_scale
            return sigma**2 * (2**(1-nu)) / np.math.gamma(nu) * \
                   (scaled_dist**nu) * np.exp(-scaled_dist)
    
    # Crear objeto del campo aleatorio
    grf = GaussianRandomFieldBootstrap(
        locations=locations,
        mean_func=mean_function,
        cov_func=matern_cov,
        random_seed=42
    )
    
    # Función estadística: máximo del campo
    def max_statistic(realization):
        return np.max(realization)
    
    # Realizar bootstrap
    boot_stats, boot_realizations = grf.bootstrap_sample(
        n_bootstrap=500,
        statistic_func=max_statistic
    )
    
    # Calcular intervalos de confianza
    ci_lower, ci_upper = grf.confidence_intervals(boot_stats, confidence_level=0.95)
    
    # Mostrar resultados
    print(f"Estadística: Máximo del campo")
    print(f"Media bootstrap: {np.mean(boot_stats):.4f}")
    print(f"Desviación estándar bootstrap: {np.std(boot_stats):.4f}")
    print(f"IC 95%: [{ci_lower:.4f}, {ci_upper:.4f}]")
    
    # Crear visualización
    plt.figure(figsize=(15, 5))
    
    # Subplot 1: Distribución bootstrap
    plt.subplot(1, 3, 1)
    plt.hist(boot_stats, bins=30, density=True, alpha=0.7, color='skyblue')
    plt.axvline(np.mean(boot_stats), color='red', linestyle='--', label='Media')
    plt.axvline(ci_lower, color='orange', linestyle='--', label='IC 95%')
    plt.axvline(ci_upper, color='orange', linestyle='--')
    plt.title('Distribución Bootstrap\ndel Máximo')
    plt.xlabel('Valor del máximo')
    plt.ylabel('Densidad')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Subplot 2: Algunas realizaciones del campo
    plt.subplot(1, 3, 2)
    for i in range(5):
        realization = boot_realizations[i].reshape(10, 10)
        plt.contour(x, y, realization, levels=10, alpha=0.6)
    plt.title('5 Realizaciones del\nCampo Gaussiano')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True, alpha=0.3)
    
    # Subplot 3: Media de las realizaciones
    plt.subplot(1, 3, 3)
    mean_realization = np.mean(boot_realizations, axis=0).reshape(10, 10)
    contour = plt.contourf(x, y, mean_realization, levels=20, cmap='viridis')
    plt.colorbar(contour)
    plt.title('Media de las\nRealizaciones Bootstrap')
    plt.xlabel('x')
    plt.ylabel('y')
    
    plt.tight_layout()
    plt.show()
    
    return boot_stats, boot_realizations

# Ejemplo con diferentes estadísticos con la comparación de estos mismos
def ejemplo_multiple_estadisticos():
    print("\n Comparación de Estadísticos \n")
    
    # Campo 1D simple
    locations = [(i,) for i in np.linspace(0, 5, 20)]
    
    grf = GaussianRandomFieldBootstrap(locations=locations, random_seed=123)
    
    # Diferentes estadísticos
    estadisticos = {
        'Media': np.mean,
        'Mediana': np.median,
        'Desv. Estándar': np.std,
        'Rango': lambda x: np.max(x) - np.min(x)
    }
    
    resultados = {}
    
    for nombre, func in estadisticos.items():
        boot_stats, _ = grf.bootstrap_sample(n_bootstrap=300, statistic_func=func)
        ci_lower, ci_upper = grf.confidence_intervals(boot_stats)
        
        resultados[nombre] = {
            'media': np.mean(boot_stats),
            'std': np.std(boot_stats),
            'ci': (ci_lower, ci_upper)
        }
        
        print(f"{nombre:12}: {np.mean(boot_stats):8.4f} ± {np.std(boot_stats):6.4f}, "
              f"IC 95%: [{ci_lower:6.4f}, {ci_upper:6.4f}]")

if __name__ == "__main__":
    # Ejemplos
    boot_stats, boot_realizations = ejemplo_bootstrap_2d()
    ejemplo_multiple_estadisticos()